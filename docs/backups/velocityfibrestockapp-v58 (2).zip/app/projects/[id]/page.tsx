"use client"

import type React from "react"

import { useState, useEffect, useMemo } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  ArrowLeft,
  Edit,
  MapPin,
  CalendarDays,
  UserCircle,
  DollarSign,
  Building,
  Mail,
  Phone,
  Activity,
  Flag,
  AlertTriangle,
  CheckCircle,
  PlayCircle,
  Circle,
  MoreVertical,
  Save,
  X,
  ListChecks,
  Layers,
  Plus,
  User,
} from "lucide-react"
import { mockProjectDetails } from "@/lib/mock-project-details"
import { notFound, useParams, useRouter } from "next/navigation"
import type { Project, ProjectPhase, ProjectPhaseStatus } from "@/lib/types"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { toast } from "@/components/ui/use-toast"

// Helper function to format currency
const formatCurrency = (amount: number | undefined) => {
  if (amount === undefined) return "N/A"
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", minimumFractionDigits: 0 }).format(amount)
}

export default function ProjectDetailsPage() {
  const params = useParams()
  const router = useRouter()
  const projectId = params.id as string

  const [project, setProject] = useState<Project | null>(null)
  const [isFlagDialogOpen, setIsFlagDialogOpen] = useState(false)
  const [currentFlaggingPhaseIndex, setCurrentFlaggingPhaseIndex] = useState<number | null>(null)
  const [flagReason, setFlagReason] = useState("")
  const [editingPhaseIndex, setEditingPhaseIndex] = useState<number | null>(null)
  const [editingPhaseData, setEditingPhaseData] = useState<Partial<ProjectPhase>>({})
  const [activeTab, setActiveTab] = useState("overview")

  const [taskStatuses, setTaskStatuses] = useState<Record<string, string>>({
    "project-scoping": "Pending",
    "budget-approval": "Pending",
    "project-kickoff": "Pending",
    "resource-allocation": "Pending",
    "permits-approvals": "Pending",
    "pole-permissions": "Pending",
    trenching: "Pending",
    "duct-installation": "Pending",
    "cable-laying": "Pending",
    "fiber-splicing": "Pending",
    "equipment-installation": "Pending",
    "network-testing": "Pending",
    "asbuilt-docs": "Pending",
    "quality-testing": "Pending",
    "safety-compliance": "Pending",
    "client-training": "Pending",
    "handover-docs": "Pending",
    "warranty-setup": "Pending",
    "final-inspection": "Pending",
    "closure-docs": "Pending",
    "lessons-learned": "Pending",
    "acceptance-certificate": "Pending",
  })

  useEffect(() => {
    const foundProject = mockProjectDetails.find((p) => p.id === projectId)
    if (foundProject) {
      // Calculate overall progress if not provided
      const updatedProject = { ...foundProject }
      if (updatedProject.overallProgress === undefined && updatedProject.projectPhases) {
        const completedPhases = updatedProject.projectPhases.filter((p) => p.status === "Completed").length
        updatedProject.overallProgress = Math.round((completedPhases / updatedProject.projectPhases.length) * 100)
      }
      // Set current phase name and progress if not provided
      if (updatedProject.currentPhaseName === undefined && updatedProject.projectPhases) {
        const activePhase =
          updatedProject.projectPhases.find((p) => p.status === "Started") ||
          updatedProject.projectPhases.find((p) => p.status === "Pending") ||
          updatedProject.projectPhases[updatedProject.projectPhases.length - 1]
        if (activePhase) {
          updatedProject.currentPhaseName = activePhase.name
          updatedProject.currentPhaseProgress =
            activePhase.progress ||
            (activePhase.status === "Completed" ? 100 : activePhase.status === "Started" ? 50 : 0)
        }
      }
      setProject(updatedProject)
    } else {
      notFound()
    }
  }, [projectId])

  const projectPhases = useMemo(() => project?.projectPhases || [], [project])

  if (!project) {
    return (
      <div className="flex justify-center items-center h-screen">
        <p>Loading project details...</p>
      </div>
    )
  }

  const getStatusBadge = (status: string | undefined) => {
    switch (status) {
      case "In Progress":
        return <Badge className="bg-blue-600 hover:bg-blue-700 text-white">{status}</Badge>
      case "Planned":
        return <Badge variant="secondary">{status}</Badge>
      case "Completed":
        return <Badge className="bg-green-600 hover:bg-green-700 text-white">{status}</Badge>
      case "Active":
        return <Badge className="bg-green-600 hover:bg-green-700 text-white">{status}</Badge>
      default:
        return <Badge variant="outline">{status || "Unknown"}</Badge>
    }
  }

  const handlePhaseStatusChange = (phaseIndex: number) => {
    setProject((prevProject) => {
      if (!prevProject || !prevProject.projectPhases) return prevProject

      const newPhases = [...prevProject.projectPhases]
      const currentPhase = newPhases[phaseIndex]
      let nextStatus: ProjectPhaseStatus = "Pending"

      // Cycle through statuses: Pending -> Started -> Flagged -> Completed -> Pending
      if (currentPhase.status === "Pending") {
        nextStatus = "Started"
      } else if (currentPhase.status === "Started") {
        nextStatus = "Flagged"
      } else if (currentPhase.status === "Flagged") {
        nextStatus = "Completed"
      } else if (currentPhase.status === "Completed") {
        nextStatus = "Pending"
      }

      // Update the phase status and set isFlagged appropriately
      newPhases[phaseIndex] = {
        ...currentPhase,
        status: nextStatus,
        isFlagged: nextStatus === "Flagged",
      }

      toast({
        title: "Phase Status Updated",
        description: `Phase "${newPhases[phaseIndex].name}" is now ${nextStatus}.`,
      })

      return { ...prevProject, projectPhases: newPhases }
    })
  }

  const openFlagDialog = (phaseIndex: number) => {
    setCurrentFlaggingPhaseIndex(phaseIndex)
    setFlagReason(project.projectPhases?.[phaseIndex]?.flagReason || "")
    setIsFlagDialogOpen(true)
  }

  const handleSaveFlagReason = () => {
    if (currentFlaggingPhaseIndex === null) return
    setProject((prevProject) => {
      if (!prevProject || !prevProject.projectPhases) return prevProject
      const newPhases = [...prevProject.projectPhases]
      newPhases[currentFlaggingPhaseIndex] = {
        ...newPhases[currentFlaggingPhaseIndex],
        isFlagged: true,
        flagReason: flagReason,
      }
      toast({
        title: "Phase Flagged",
        description: `Phase "${newPhases[currentFlaggingPhaseIndex].name}" has been flagged.`,
      })
      return { ...prevProject, projectPhases: newPhases }
    })
    setIsFlagDialogOpen(false)
    setCurrentFlaggingPhaseIndex(null)
    setFlagReason("")
  }

  const handleUnflagPhase = (phaseIndex: number) => {
    setProject((prevProject) => {
      if (!prevProject || !prevProject.projectPhases) return prevProject
      const newPhases = [...prevProject.projectPhases]
      newPhases[phaseIndex] = { ...newPhases[phaseIndex], isFlagged: false, flagReason: "" }
      toast({ title: "Phase Unflagged", description: `Phase "${newPhases[phaseIndex].name}" is no longer flagged.` })
      return { ...prevProject, projectPhases: newPhases }
    })
  }

  const getPhaseStatusIndicator = (status: ProjectPhaseStatus) => {
    switch (status) {
      case "Pending":
        return <Circle className="h-5 w-5 text-gray-400" />
      case "Started":
        return <PlayCircle className="h-5 w-5 text-blue-500" />
      case "Completed":
        return <CheckCircle className="h-5 w-5 text-green-500" />
      default:
        return <Circle className="h-5 w-5 text-gray-400" />
    }
  }

  const startEditingPhase = (index: number) => {
    setEditingPhaseIndex(index)
    setEditingPhaseData(project.projectPhases?.[index] || {})
  }

  const handleEditingPhaseChange = (field: keyof ProjectPhase, value: string) => {
    setEditingPhaseData((prev) => ({ ...prev, [field]: value }))
  }

  const saveEditingPhase = () => {
    if (editingPhaseIndex === null) return
    setProject((prevProject) => {
      if (!prevProject || !prevProject.projectPhases) return prevProject
      const newPhases = [...prevProject.projectPhases]
      newPhases[editingPhaseIndex] = { ...newPhases[editingPhaseIndex], ...editingPhaseData } as ProjectPhase
      toast({ title: "Phase Updated", description: `Phase "${newPhases[editingPhaseIndex].name}" has been updated.` })
      return { ...prevProject, projectPhases: newPhases }
    })
    setEditingPhaseIndex(null)
    setEditingPhaseData({})
  }

  const cancelEditingPhase = () => {
    setEditingPhaseIndex(null)
    setEditingPhaseData({})
  }

  const handleTaskStatusChange = (taskId: string) => {
    setTaskStatuses((prev) => {
      const currentStatus = prev[taskId] || "Pending"
      let nextStatus = "Pending"

      // Cycle through statuses: Pending -> In Progress -> Completed -> Pending
      if (currentStatus === "Pending") {
        nextStatus = "In Progress"
      } else if (currentStatus === "In Progress") {
        nextStatus = "Completed"
      } else if (currentStatus === "Completed") {
        nextStatus = "Pending"
      }

      toast({
        title: "Task Status Updated",
        description: `Task status changed to ${nextStatus}.`,
      })

      return { ...prev, [taskId]: nextStatus }
    })
  }

  const getTaskStatusBadge = (status: string) => {
    switch (status) {
      case "In Progress":
        return <Badge className="bg-blue-600 hover:bg-blue-700 text-white">In Progress</Badge>
      case "Completed":
        return <Badge className="bg-green-600 hover:bg-green-700 text-white">Completed</Badge>
      case "Pending":
      default:
        return <Badge variant="outline">Pending</Badge>
    }
  }

  const handleBackClick = () => {
    // Navigate back to the projects list in the app, not the file system
    window.history.back()
  }

  const StatCard = ({
    title,
    value,
    subValue,
    icon: Icon,
    progressValue,
    progressTotalLabel,
  }: {
    title: string
    value: string
    subValue?: string
    icon: React.ElementType
    progressValue?: number
    progressTotalLabel?: string
  }) => (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        {subValue && <p className="text-xs text-muted-foreground">{subValue}</p>}
        {progressValue !== undefined && (
          <div className="mt-2">
            <Progress value={progressValue} className="h-2" />
            {progressTotalLabel && <p className="text-xs text-muted-foreground mt-1">{progressTotalLabel}</p>}
          </div>
        )}
      </CardContent>
    </Card>
  )

  const createIndividualTask = (phaseTaskId: string, phaseTaskName: string) => {
    // This would create a task in the main tasks system
    const newTask = {
      id: Date.now(),
      title: phaseTaskName,
      project: project.name,
      assignee: "Unassigned", // Could open assignment dialog
      dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split("T")[0], // 7 days from now
      priority: "Medium" as "High" | "Medium" | "Low",
      status: "Not Started" as "Not Started" | "In Progress" | "Completed",
      description: `Task from ${project.name} project phase`,
      projectPhaseTask: true,
      phaseTaskId: phaseTaskId,
    }

    toast({
      title: "Individual Task Created",
      description: `"${phaseTaskName}" has been added to the main tasks list`,
    })
  }

  return (
    <div className="container mx-auto p-4 md:p-6 space-y-6 bg-background">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div className="flex items-center gap-3">
          <Button variant="outline" size="icon" className="h-9 w-9" onClick={handleBackClick}>
            <ArrowLeft className="h-5 w-5" />
            <span className="sr-only">Back to Projects</span>
          </Button>
          <div>
            <h1 className="text-2xl font-bold tracking-tight">{project.name}</h1>
            <p className="text-sm text-muted-foreground max-w-2xl">
              {project.description || "No description available."}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 flex-shrink-0">
          {getStatusBadge(project.status)}
          <Button variant="default">
            <Edit className="h-4 w-4 mr-2" />
            Edit Project
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Overall Progress"
          value={`${project.overallProgress || 0}%`}
          icon={Activity}
          progressValue={project.overallProgress || 0}
        />
        <StatCard
          title="Budget Used"
          value={formatCurrency(project.budgetUsed)}
          subValue={`of ${formatCurrency(project.budget)} budget`}
          icon={DollarSign}
          progressValue={project.budget && project.budgetUsed ? (project.budgetUsed / project.budget) * 100 : 0}
        />
        <StatCard
          title="Active Tasks"
          value={project.activeTasksCount?.toString() || "0"}
          subValue={`${project.completedTasksCount || 0} completed`}
          icon={ListChecks}
        />
        <StatCard
          title="Current Phase"
          value={project.currentPhaseName || "N/A"}
          subValue={`${project.currentPhaseProgress || 0}% complete`}
          icon={Layers}
          progressValue={project.currentPhaseProgress || 0}
        />
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2 sm:grid-cols-3 md:grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="phases">Phases</TabsTrigger>
          <TabsTrigger value="tasks">Tasks</TabsTrigger>
          <TabsTrigger value="materials">Materials</TabsTrigger>
          <TabsTrigger value="contractors">Contractors</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-6">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Project Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div className="flex items-center">
                  <MapPin className="h-4 w-4 mr-3 text-muted-foreground flex-shrink-0" />
                  <span>{project.location}</span>
                </div>
                <div className="flex items-center">
                  <CalendarDays className="h-4 w-4 mr-3 text-muted-foreground flex-shrink-0" />
                  <span>
                    {new Date(project.startDate).toLocaleDateString()} -{" "}
                    {new Date(project.endDate).toLocaleDateString()}
                  </span>
                </div>
                <div className="flex items-center">
                  <UserCircle className="h-4 w-4 mr-3 text-muted-foreground flex-shrink-0" />
                  <span>{project.projectManager}</span>
                </div>
                <div className="flex items-center">
                  <DollarSign className="h-4 w-4 mr-3 text-muted-foreground flex-shrink-0" />
                  <span>{formatCurrency(project.budget)}</span>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Customer Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div className="flex items-center">
                  <Building className="h-4 w-4 mr-3 text-muted-foreground flex-shrink-0" />
                  <span>{project.customer || "N/A"}</span>
                </div>
                <div className="flex items-center">
                  <UserCircle className="h-4 w-4 mr-3 text-muted-foreground flex-shrink-0" />
                  <span>Contact: {project.customerContact || "N/A"}</span>
                </div>
                <div className="flex items-center">
                  <Mail className="h-4 w-4 mr-3 text-muted-foreground flex-shrink-0" />
                  <span>{project.customerEmail || "N/A"}</span>
                </div>
                <div className="flex items-center">
                  <Phone className="h-4 w-4 mr-3 text-muted-foreground flex-shrink-0" />
                  <span>{project.customerPhone || "N/A"}</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="phases" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Project Phases</CardTitle>
              <CardDescription>
                Click status button to cycle through: Pending → Started → Flagged → Completed. Click phase details to
                edit.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {projectPhases.map((phase, index) => (
                <div
                  key={index}
                  className={`border p-4 rounded-md ${phase.isFlagged ? "border-red-500 bg-red-50 dark:bg-red-900/30" : "border-border"}`}
                >
                  {editingPhaseIndex === index ? (
                    <div className="space-y-3">
                      <Input
                        value={editingPhaseData.name || ""}
                        onChange={(e) => handleEditingPhaseChange("name", e.target.value)}
                        placeholder="Phase Name"
                        className="text-lg font-semibold"
                      />
                      <Input
                        value={editingPhaseData.duration || ""}
                        onChange={(e) => handleEditingPhaseChange("duration", e.target.value)}
                        placeholder="Duration (e.g., 1 week)"
                      />
                      <Textarea
                        value={editingPhaseData.description || ""}
                        onChange={(e) => handleEditingPhaseChange("description", e.target.value)}
                        placeholder="Description"
                        rows={2}
                      />
                      <Textarea
                        value={editingPhaseData.deliverables || ""}
                        onChange={(e) => handleEditingPhaseChange("deliverables", e.target.value)}
                        placeholder="Key Deliverables"
                        rows={2}
                      />
                      <div className="flex justify-end gap-2">
                        <Button variant="ghost" size="sm" onClick={cancelEditingPhase}>
                          <X className="h-4 w-4 mr-1" /> Cancel
                        </Button>
                        <Button size="sm" onClick={saveEditingPhase}>
                          <Save className="h-4 w-4 mr-1" /> Save
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-start justify-between">
                      <div className="flex-grow cursor-pointer" onClick={() => startEditingPhase(index)}>
                        <div className="flex items-center">
                          <h3 className="text-lg font-semibold">
                            {index + 1}. {phase.name}
                            {phase.isFlagged && <Flag className="h-5 w-5 text-red-500 ml-2 inline-block" />}
                          </h3>
                        </div>
                        <Badge variant="secondary" className="mt-1">
                          {phase.duration}
                        </Badge>
                        <p className="text-sm text-muted-foreground mt-2">{phase.description}</p>
                        <p className="text-sm mt-2">
                          <span className="font-medium">Key Deliverables:</span> {phase.deliverables}
                        </p>
                        {phase.isFlagged && phase.flagReason && (
                          <p className="text-sm mt-2 text-red-600 italic">
                            <span className="font-medium">Flag Reason:</span> {phase.flagReason}
                          </p>
                        )}
                      </div>
                      <div className="flex items-center gap-2 flex-shrink-0">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation()
                            handlePhaseStatusChange(index)
                          }}
                          className={`
  ${
    phase.status === "Flagged"
      ? "border-red-400 text-red-700 bg-red-50 hover:bg-red-100"
      : phase.status === "Pending"
        ? "border-gray-400 text-gray-600 bg-gray-50 hover:bg-gray-100"
        : phase.status === "Started"
          ? "border-orange-400 text-orange-700 bg-orange-50 hover:bg-orange-100"
          : phase.status === "Completed"
            ? "border-green-400 text-green-700 bg-green-50 hover:bg-green-100"
            : "border-gray-400 text-gray-600 bg-gray-50 hover:bg-gray-100"
  }
`}
                        >
                          {phase.status}
                        </Button>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8 flex-shrink-0">
                              <MoreVertical className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => startEditingPhase(index)}>
                              <Edit className="mr-2 h-4 w-4" /> Edit Phase
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => openFlagDialog(index)}>
                              <Flag className="mr-2 h-4 w-4" />
                              {phase.isFlagged ? "Edit Flag Reason" : "Flag Phase"}
                            </DropdownMenuItem>
                            {phase.isFlagged && (
                              <DropdownMenuItem onClick={() => handleUnflagPhase(index)} className="text-red-600">
                                <AlertTriangle className="mr-2 h-4 w-4" /> Unflag Phase
                              </DropdownMenuItem>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="tasks" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Project Tasks</CardTitle>
              <CardDescription>
                Click on any task to change its status: Pending → In Progress → Completed
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Initiate Project (IP) Phase */}
              <div className="space-y-3">
                <h3 className="text-lg font-semibold flex items-center">
                  <Circle className="h-5 w-5 mr-2 text-blue-500" />
                  Initiate Project (IP) Phase
                </h3>
                <div className="ml-7 space-y-4">
                  <div>
                    <h4 className="font-medium text-sm text-muted-foreground mb-2">Planning & Setup</h4>
                    <div className="space-y-2">
                      <div
                        className="flex items-center justify-between p-2 border rounded cursor-pointer hover:bg-gray-50 transition-colors"
                        onClick={() => handleTaskStatusChange("project-scoping")}
                      >
                        <span className="text-sm">Project scoping and design</span>
                        <div className="flex items-center">
                          {getTaskStatusBadge(taskStatuses["project-scoping"])}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={(e) => {
                              e.stopPropagation()
                              createIndividualTask("project-scoping", "Project scoping and design")
                            }}
                            className="ml-2"
                          >
                            <Plus className="h-3 w-3 mr-1" />
                            Assign
                          </Button>
                          {taskStatuses["project-scoping"] === "Assigned" && (
                            <Badge variant="secondary" className="ml-2">
                              <User className="h-3 w-3 mr-1" />
                              Assigned
                            </Badge>
                          )}
                        </div>
                      </div>
                      <div
                        className="flex items-center justify-between p-2 border rounded cursor-pointer hover:bg-gray-50 transition-colors"
                        onClick={() => handleTaskStatusChange("budget-approval")}
                      >
                        <span className="text-sm">Budget approval and allocation</span>
                        <div className="flex items-center">
                          {getTaskStatusBadge(taskStatuses["budget-approval"])}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={(e) => {
                              e.stopPropagation()
                              createIndividualTask("budget-approval", "Budget approval and allocation")
                            }}
                            className="ml-2"
                          >
                            <Plus className="h-3 w-3 mr-1" />
                            Assign
                          </Button>
                          {taskStatuses["budget-approval"] === "Assigned" && (
                            <Badge variant="secondary" className="ml-2">
                              <User className="h-3 w-3 mr-1" />
                              Assigned
                            </Badge>
                          )}
                        </div>
                      </div>
                      <div
                        className="flex items-center justify-between p-2 border rounded cursor-pointer hover:bg-gray-50 transition-colors"
                        onClick={() => handleTaskStatusChange("project-kickoff")}
                      >
                        <span className="text-sm">Project kick-off meeting</span>
                        <div className="flex items-center">
                          {getTaskStatusBadge(taskStatuses["project-kickoff"])}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={(e) => {
                              e.stopPropagation()
                              createIndividualTask("project-kickoff", "Project kick-off meeting")
                            }}
                            className="ml-2"
                          >
                            <Plus className="h-3 w-3 mr-1" />
                            Assign
                          </Button>
                          {taskStatuses["project-kickoff"] === "Assigned" && (
                            <Badge variant="secondary" className="ml-2">
                              <User className="h-3 w-3 mr-1" />
                              Assigned
                            </Badge>
                          )}
                        </div>
                      </div>
                      <div
                        className="flex items-center justify-between p-2 border rounded cursor-pointer hover:bg-gray-50 transition-colors"
                        onClick={() => handleTaskStatusChange("resource-allocation")}
                      >
                        <span className="text-sm">Resource allocation and team assignment</span>
                        <div className="flex items-center">
                          {getTaskStatusBadge(taskStatuses["resource-allocation"])}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={(e) => {
                              e.stopPropagation()
                              createIndividualTask("resource-allocation", "Resource allocation and team assignment")
                            }}
                            className="ml-2"
                          >
                            <Plus className="h-3 w-3 mr-1" />
                            Assign
                          </Button>
                          {taskStatuses["resource-allocation"] === "Assigned" && (
                            <Badge variant="secondary" className="ml-2">
                              <User className="h-3 w-3 mr-1" />
                              Assigned
                            </Badge>
                          )}
                        </div>
                      </div>
                      <div
                        className="flex items-center justify-between p-2 border rounded cursor-pointer hover:bg-gray-50 transition-colors"
                        onClick={() => handleTaskStatusChange("permits-approvals")}
                      >
                        <span className="text-sm">Permits and regulatory approvals</span>
                        <div className="flex items-center">
                          {getTaskStatusBadge(taskStatuses["permits-approvals"])}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={(e) => {
                              e.stopPropagation()
                              createIndividualTask("permits-approvals", "Permits and regulatory approvals")
                            }}
                            className="ml-2"
                          >
                            <Plus className="h-3 w-3 mr-1" />
                            Assign
                          </Button>
                          {taskStatuses["permits-approvals"] === "Assigned" && (
                            <Badge variant="secondary" className="ml-2">
                              <User className="h-3 w-3 mr-1" />
                              Assigned
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Work in Progress (WIP) Phase */}
              <div className="space-y-3">
                <h3 className="text-lg font-semibold flex items-center">
                  <PlayCircle className="h-5 w-5 mr-2 text-orange-500" />
                  Work in Progress (WIP) Phase
                </h3>
                <div className="ml-7 space-y-4">
                  <div>
                    <h4 className="font-medium text-sm text-muted-foreground mb-2">Civils Work</h4>
                    <div className="space-y-2">
                      <div
                        className="flex items-center justify-between p-2 border rounded cursor-pointer hover:bg-gray-50 transition-colors"
                        onClick={() => handleTaskStatusChange("pole-permissions")}
                      >
                        <span className="text-sm">Pole permissions and wayleaves</span>
                        <div className="flex items-center">
                          {getTaskStatusBadge(taskStatuses["pole-permissions"])}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={(e) => {
                              e.stopPropagation()
                              createIndividualTask("pole-permissions", "Pole permissions and wayleaves")
                            }}
                            className="ml-2"
                          >
                            <Plus className="h-3 w-3 mr-1" />
                            Assign
                          </Button>
                          {taskStatuses["pole-permissions"] === "Assigned" && (
                            <Badge variant="secondary" className="ml-2">
                              <User className="h-3 w-3 mr-1" />
                              Assigned
                            </Badge>
                          )}
                        </div>
                      </div>
                      <div
                        className="flex items-center justify-between p-2 border rounded cursor-pointer hover:bg-gray-50 transition-colors"
                        onClick={() => handleTaskStatusChange("trenching")}
                      >
                        <span className="text-sm">Trenching and excavation</span>
                        <div className="flex items-center">
                          {getTaskStatusBadge(taskStatuses["trenching"])}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={(e) => {
                              e.stopPropagation()
                              createIndividualTask("trenching", "Trenching and excavation")
                            }}
                            className="ml-2"
                          >
                            <Plus className="h-3 w-3 mr-1" />
                            Assign
                          </Button>
                          {taskStatuses["trenching"] === "Assigned" && (
                            <Badge variant="secondary" className="ml-2">
                              <User className="h-3 w-3 mr-1" />
                              Assigned
                            </Badge>
                          )}
                        </div>
                      </div>
                      <div
                        className="flex items-center justify-between p-2 border rounded cursor-pointer hover:bg-gray-50 transition-colors"
                        onClick={() => handleTaskStatusChange("duct-installation")}
                      >
                        <span className="text-sm">Duct installation</span>
                        <div className="flex items-center">
                          {getTaskStatusBadge(taskStatuses["duct-installation"])}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={(e) => {
                              e.stopPropagation()
                              createIndividualTask("duct-installation", "Duct installation")
                            }}
                            className="ml-2"
                          >
                            <Plus className="h-3 w-3 mr-1" />
                            Assign
                          </Button>
                          {taskStatuses["duct-installation"] === "Assigned" && (
                            <Badge variant="secondary" className="ml-2">
                              <User className="h-3 w-3 mr-1" />
                              Assigned
                            </Badge>
                          )}
                        </div>
                      </div>
                      <div
                        className="flex items-center justify-between p-2 border rounded cursor-pointer hover:bg-gray-50 transition-colors"
                        onClick={() => handleTaskStatusChange("cable-laying")}
                      >
                        <span className="text-sm">Cable laying and pulling</span>
                        <div className="flex items-center">
                          {getTaskStatusBadge(taskStatuses["cable-laying"])}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={(e) => {
                              e.stopPropagation()
                              createIndividualTask("cable-laying", "Cable laying and pulling")
                            }}
                            className="ml-2"
                          >
                            <Plus className="h-3 w-3 mr-1" />
                            Assign
                          </Button>
                          {taskStatuses["cable-laying"] === "Assigned" && (
                            <Badge variant="secondary" className="ml-2">
                              <User className="h-3 w-3 mr-1" />
                              Assigned
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                  <div>
                    <h4 className="font-medium text-sm text-muted-foreground mb-2">Optical Work</h4>
                    <div className="space-y-2">
                      <div
                        className="flex items-center justify-between p-2 border rounded cursor-pointer hover:bg-gray-50 transition-colors"
                        onClick={() => handleTaskStatusChange("fiber-splicing")}
                      >
                        <span className="text-sm">Fiber splicing and termination</span>
                        <div className="flex items-center">
                          {getTaskStatusBadge(taskStatuses["fiber-splicing"])}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={(e) => {
                              e.stopPropagation()
                              createIndividualTask("fiber-splicing", "Fiber splicing and termination")
                            }}
                            className="ml-2"
                          >
                            <Plus className="h-3 w-3 mr-1" />
                            Assign
                          </Button>
                          {taskStatuses["fiber-splicing"] === "Assigned" && (
                            <Badge variant="secondary" className="ml-2">
                              <User className="h-3 w-3 mr-1" />
                              Assigned
                            </Badge>
                          )}
                        </div>
                      </div>
                      <div
                        className="flex items-center justify-between p-2 border rounded cursor-pointer hover:bg-gray-50 transition-colors"
                        onClick={() => handleTaskStatusChange("equipment-installation")}
                      >
                        <span className="text-sm">Equipment installation and configuration</span>
                        <div className="flex items-center">
                          {getTaskStatusBadge(taskStatuses["equipment-installation"])}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={(e) => {
                              e.stopPropagation()
                              createIndividualTask("equipment-installation", "Equipment installation and configuration")
                            }}
                            className="ml-2"
                          >
                            <Plus className="h-3 w-3 mr-1" />
                            Assign
                          </Button>
                          {taskStatuses["equipment-installation"] === "Assigned" && (
                            <Badge variant="secondary" className="ml-2">
                              <User className="h-3 w-3 mr-1" />
                              Assigned
                            </Badge>
                          )}
                        </div>
                      </div>
                      <div
                        className="flex items-center justify-between p-2 border rounded cursor-pointer hover:bg-gray-50 transition-colors"
                        onClick={() => handleTaskStatusChange("network-testing")}
                      >
                        <span className="text-sm">Network testing and commissioning</span>
                        <div className="flex items-center">
                          {getTaskStatusBadge(taskStatuses["network-testing"])}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={(e) => {
                              e.stopPropagation()
                              createIndividualTask("network-testing", "Network testing and commissioning")
                            }}
                            className="ml-2"
                          >
                            <Plus className="h-3 w-3 mr-1" />
                            Assign
                          </Button>
                          {taskStatuses["network-testing"] === "Assigned" && (
                            <Badge variant="secondary" className="ml-2">
                              <User className="h-3 w-3 mr-1" />
                              Assigned
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                  <div>
                    <h4 className="font-medium text-sm text-muted-foreground mb-2">Documentation & QA</h4>
                    <div className="space-y-2">
                      <div
                        className="flex items-center justify-between p-2 border rounded cursor-pointer hover:bg-gray-50 transition-colors"
                        onClick={() => handleTaskStatusChange("asbuilt-docs")}
                      >
                        <span className="text-sm">As-built documentation</span>
                        <div className="flex items-center">
                          {getTaskStatusBadge(taskStatuses["asbuilt-docs"])}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={(e) => {
                              e.stopPropagation()
                              createIndividualTask("asbuilt-docs", "As-built documentation")
                            }}
                            className="ml-2"
                          >
                            <Plus className="h-3 w-3 mr-1" />
                            Assign
                          </Button>
                          {taskStatuses["asbuilt-docs"] === "Assigned" && (
                            <Badge variant="secondary" className="ml-2">
                              <User className="h-3 w-3 mr-1" />
                              Assigned
                            </Badge>
                          )}
                        </div>
                      </div>
                      <div
                        className="flex items-center justify-between p-2 border rounded cursor-pointer hover:bg-gray-50 transition-colors"
                        onClick={() => handleTaskStatusChange("quality-testing")}
                      >
                        <span className="text-sm">Quality assurance testing</span>
                        <div className="flex items-center">
                          {getTaskStatusBadge(taskStatuses["quality-testing"])}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={(e) => {
                              e.stopPropagation()
                              createIndividualTask("quality-testing", "Quality assurance testing")
                            }}
                            className="ml-2"
                          >
                            <Plus className="h-3 w-3 mr-1" />
                            Assign
                          </Button>
                          {taskStatuses["quality-testing"] === "Assigned" && (
                            <Badge variant="secondary" className="ml-2">
                              <User className="h-3 w-3 mr-1" />
                              Assigned
                            </Badge>
                          )}
                        </div>
                      </div>
                      <div
                        className="flex items-center justify-between p-2 border rounded cursor-pointer hover:bg-gray-50 transition-colors"
                        onClick={() => handleTaskStatusChange("safety-compliance")}
                      >
                        <span className="text-sm">Health and safety compliance check</span>
                        <div className="flex items-center">
                          {getTaskStatusBadge(taskStatuses["safety-compliance"])}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={(e) => {
                              e.stopPropagation()
                              createIndividualTask("safety-compliance", "Health and safety compliance check")
                            }}
                            className="ml-2"
                          >
                            <Plus className="h-3 w-3 mr-1" />
                            Assign
                          </Button>
                          {taskStatuses["safety-compliance"] === "Assigned" && (
                            <Badge variant="secondary" className="ml-2">
                              <User className="h-3 w-3 mr-1" />
                              Assigned
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Handover Phase */}
              <div className="space-y-3">
                <h3 className="text-lg font-semibold flex items-center">
                  <Circle className="h-5 w-5 mr-2 text-gray-400" />
                  Handover Phase
                </h3>
                <div className="ml-7 space-y-4">
                  <div>
                    <h4 className="font-medium text-sm text-muted-foreground mb-2">Client Transition</h4>
                    <div className="space-y-2">
                      <div
                        className="flex items-center justify-between p-2 border rounded cursor-pointer hover:bg-gray-50 transition-colors"
                        onClick={() => handleTaskStatusChange("client-training")}
                      >
                        <span className="text-sm">Client training and knowledge transfer</span>
                        <div className="flex items-center">
                          {getTaskStatusBadge(taskStatuses["client-training"])}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={(e) => {
                              e.stopPropagation()
                              createIndividualTask("client-training", "Client training and knowledge transfer")
                            }}
                            className="ml-2"
                          >
                            <Plus className="h-3 w-3 mr-1" />
                            Assign
                          </Button>
                          {taskStatuses["client-training"] === "Assigned" && (
                            <Badge variant="secondary" className="ml-2">
                              <User className="h-3 w-3 mr-1" />
                              Assigned
                            </Badge>
                          )}
                        </div>
                      </div>
                      <div
                        className="flex items-center justify-between p-2 border rounded cursor-pointer hover:bg-gray-50 transition-colors"
                        onClick={() => handleTaskStatusChange("handover-docs")}
                      >
                        <span className="text-sm">System handover documentation</span>
                        <div className="flex items-center">
                          {getTaskStatusBadge(taskStatuses["handover-docs"])}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={(e) => {
                              e.stopPropagation()
                              createIndividualTask("handover-docs", "System handover documentation")
                            }}
                            className="ml-2"
                          >
                            <Plus className="h-3 w-3 mr-1" />
                            Assign
                          </Button>
                          {taskStatuses["handover-docs"] === "Assigned" && (
                            <Badge variant="secondary" className="ml-2">
                              <User className="h-3 w-3 mr-1" />
                              Assigned
                            </Badge>
                          )}
                        </div>
                      </div>
                      <div
                        className="flex items-center justify-between p-2 border rounded cursor-pointer hover:bg-gray-50 transition-colors"
                        onClick={() => handleTaskStatusChange("warranty-setup")}
                      >
                        <span className="text-sm">Warranty and support setup</span>
                        <div className="flex items-center">
                          {getTaskStatusBadge(taskStatuses["warranty-setup"])}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={(e) => {
                              e.stopPropagation()
                              createIndividualTask("warranty-setup", "Warranty and support setup")
                            }}
                            className="ml-2"
                          >
                            <Plus className="h-3 w-3 mr-1" />
                            Assign
                          </Button>
                          {taskStatuses["warranty-setup"] === "Assigned" && (
                            <Badge variant="secondary" className="ml-2">
                              <User className="h-3 w-3 mr-1" />
                              Assigned
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Final Acceptance Certificate (FAC) Phase */}
              <div className="space-y-3">
                <h3 className="text-lg font-semibold flex items-center">
                  <Circle className="h-5 w-5 mr-2 text-gray-400" />
                  Final Acceptance Certificate (FAC) Phase
                </h3>
                <div className="ml-7 space-y-4">
                  <div>
                    <h4 className="font-medium text-sm text-muted-foreground mb-2">Project Closure</h4>
                    <div className="space-y-2">
                      <div
                        className="flex items-center justify-between p-2 border rounded cursor-pointer hover:bg-gray-50 transition-colors"
                        onClick={() => handleTaskStatusChange("final-inspection")}
                      >
                        <span className="text-sm">Final inspection and sign-off</span>
                        <div className="flex items-center">
                          {getTaskStatusBadge(taskStatuses["final-inspection"])}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={(e) => {
                              e.stopPropagation()
                              createIndividualTask("final-inspection", "Final inspection and sign-off")
                            }}
                            className="ml-2"
                          >
                            <Plus className="h-3 w-3 mr-1" />
                            Assign
                          </Button>
                          {taskStatuses["final-inspection"] === "Assigned" && (
                            <Badge variant="secondary" className="ml-2">
                              <User className="h-3 w-3 mr-1" />
                              Assigned
                            </Badge>
                          )}
                        </div>
                      </div>
                      <div
                        className="flex items-center justify-between p-2 border rounded cursor-pointer hover:bg-gray-50 transition-colors"
                        onClick={() => handleTaskStatusChange("closure-docs")}
                      >
                        <span className="text-sm">Project closure documentation</span>
                        <div className="flex items-center">
                          {getTaskStatusBadge(taskStatuses["closure-docs"])}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={(e) => {
                              e.stopPropagation()
                              createIndividualTask("closure-docs", "Project closure documentation")
                            }}
                            className="ml-2"
                          >
                            <Plus className="h-3 w-3 mr-1" />
                            Assign
                          </Button>
                          {taskStatuses["closure-docs"] === "Assigned" && (
                            <Badge variant="secondary" className="ml-2">
                              <User className="h-3 w-3 mr-1" />
                              Assigned
                            </Badge>
                          )}
                        </div>
                      </div>
                      <div
                        className="flex items-center justify-between p-2 border rounded cursor-pointer hover:bg-gray-50 transition-colors"
                        onClick={() => handleTaskStatusChange("lessons-learned")}
                      >
                        <span className="text-sm">Lessons learned documentation</span>
                        <div className="flex items-center">
                          {getTaskStatusBadge(taskStatuses["lessons-learned"])}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={(e) => {
                              e.stopPropagation()
                              createIndividualTask("lessons-learned", "Lessons learned documentation")
                            }}
                            className="ml-2"
                          >
                            <Plus className="h-3 w-3 mr-1" />
                            Assign
                          </Button>
                          {taskStatuses["lessons-learned"] === "Assigned" && (
                            <Badge variant="secondary" className="ml-2">
                              <User className="h-3 w-3 mr-1" />
                              Assigned
                            </Badge>
                          )}
                        </div>
                      </div>
                      <div
                        className="flex items-center justify-between p-2 border rounded cursor-pointer hover:bg-gray-50 transition-colors"
                        onClick={() => handleTaskStatusChange("acceptance-certificate")}
                      >
                        <span className="text-sm">Final acceptance certificate issuance</span>
                        <div className="flex items-center">
                          {getTaskStatusBadge(taskStatuses["acceptance-certificate"])}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={(e) => {
                              e.stopPropagation()
                              createIndividualTask("acceptance-certificate", "Final acceptance certificate issuance")
                            }}
                            className="ml-2"
                          >
                            <Plus className="h-3 w-3 mr-1" />
                            Assign
                          </Button>
                          {taskStatuses["acceptance-certificate"] === "Assigned" && (
                            <Badge variant="secondary" className="ml-2">
                              <User className="h-3 w-3 mr-1" />
                              Assigned
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="materials" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Materials</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">Material lists and procurement status will be displayed here.</p>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="contractors" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Contractors</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">Contractor information and assignments will be displayed here.</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Dialog open={isFlagDialogOpen} onOpenChange={setIsFlagDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Flag Project Phase</DialogTitle>
            <DialogDescription>
              Provide a reason why this phase is being flagged. This will be escalated.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="flag-reason">Reason for Flagging</Label>
              <Textarea
                id="flag-reason"
                value={flagReason}
                onChange={(e) => setFlagReason(e.target.value)}
                placeholder="Describe why this phase is stalling or needs attention..."
                rows={4}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsFlagDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveFlagReason}>Save Flag</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
