"use client"

import Image from "next/image"
import { BarChart3, Building2, Package, Users, Palette, Building, TrendingUp, ListTodo, Home } from "lucide-react"

import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "@/components/ui/sidebar"

// Define menu items for the main dashboard
const dashboardItems = [
  {
    title: "Dashboard",
    icon: Home,
    id: "dashboard",
  },
]

// Define menu items for the Materials Management section
const materialsManagementItems = [
  {
    title: "Material",
    icon: Package,
    id: "stock",
  },
  {
    title: "Stock Movements",
    icon: TrendingUp,
    id: "movements",
  },
  {
    title: "Analytics",
    icon: BarChart3,
    id: "analytics",
  },
]

// Define menu items for the Suppliers section
const suppliersItems = [
  {
    title: "Suppliers",
    icon: Users,
    id: "suppliers",
  },
  {
    title: "Supplier Portal",
    icon: Building,
    id: "supplier-portal",
  },
]

// Define menu items for the main navigation
const mainMenuItems = [
  {
    title: "Theme Settings",
    icon: Palette,
    id: "theme",
  },
]

// Define menu items for the Project Management section
const projectManagementItems = [
  {
    title: "Projects",
    icon: Building2,
    id: "projects",
  },
  {
    title: "Tasks",
    icon: ListTodo,
    id: "tasks",
  },
]

interface AppSidebarProps {
  activeModule: string
  setActiveModule: (module: string) => void
}

export function AppSidebar({ activeModule, setActiveModule }: AppSidebarProps) {
  return (
    <Sidebar>
      <SidebarHeader className="velocity-gradient-dark h-40 relative flex items-center justify-center">
        <div className="relative w-full h-full">
          <Image
            src="/images/velocity-fibre-logo.jpeg"
            alt="FibreFlow Logo"
            fill
            style={{ objectFit: "cover" }}
            priority
          />
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Main</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {dashboardItems.map((item) => (
                <SidebarMenuItem key={item.id}>
                  <SidebarMenuButton onClick={() => setActiveModule(item.id)} isActive={activeModule === item.id}>
                    <item.icon />
                    <span>{item.title}</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel>Project Management</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {projectManagementItems.map((item) => (
                <SidebarMenuItem key={item.id}>
                  <SidebarMenuButton onClick={() => setActiveModule(item.id)} isActive={activeModule === item.id}>
                    <item.icon />
                    <span>{item.title}</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel>Materials Management</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {materialsManagementItems.map((item) => (
                <SidebarMenuItem key={item.id}>
                  <SidebarMenuButton onClick={() => setActiveModule(item.id)} isActive={activeModule === item.id}>
                    <item.icon />
                    <span>{item.title}</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel>Suppliers</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {suppliersItems.map((item) => (
                <SidebarMenuItem key={item.id}>
                  <SidebarMenuButton onClick={() => setActiveModule(item.id)} isActive={activeModule === item.id}>
                    <item.icon />
                    <span>{item.title}</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel>Settings</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {mainMenuItems.map((item) => (
                <SidebarMenuItem key={item.id}>
                  <SidebarMenuButton onClick={() => setActiveModule(item.id)} isActive={activeModule === item.id}>
                    <item.icon />
                    <span>{item.title}</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  )
}
