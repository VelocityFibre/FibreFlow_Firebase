"use client"

import { useState } from "react"
import { SidebarProvider, SidebarInset, SidebarTrigger } from "@/components/ui/sidebar" // Added SidebarTrigger import
import { AppSidebar } from "@/components/app-sidebar"
import { Dashboard } from "@/components/dashboard"
import { StockItems } from "@/components/stock-items"
import { Suppliers } from "@/components/suppliers"
import { Projects } from "@/components/projects"
import { BOQManagement } from "@/components/boq-management"
import { RFQManagement } from "@/components/rfq-management"
import { StockMovements } from "@/components/stock-movements"
import { ThemeSettings } from "@/components/theme-settings"
import { SupplierPortal } from "@/components/supplier-portal"
import { QuoteAnalysis } from "@/components/quote-analysis"
import TasksPage from "@/app/tasks/page"
import { Separator } from "@/components/ui/separator" // Added Separator import
import { AnalyticsDashboard } from "@/components/analytics-dashboard"

export default function Home() {
  const [activeModule, setActiveModule] = useState("dashboard")

  const renderModule = () => {
    switch (activeModule) {
      case "dashboard":
        return <Dashboard setActiveModule={setActiveModule} />
      case "stock":
        return <StockItems setActiveModule={setActiveModule} />
      case "suppliers":
        return <Suppliers setActiveModule={setActiveModule} />
      case "projects":
        return <Projects />
      case "boq":
        return <BOQManagement />
      case "rfq":
        return <RFQManagement />
      case "movements":
        return <StockMovements />
      case "analytics":
        return <AnalyticsDashboard />
      case "supplier-portal":
        return <SupplierPortal supplierId="SUP-001" />
      case "theme":
        return <ThemeSettings />
      case "quote-analysis":
        return <QuoteAnalysis />
      case "tasks":
        return <TasksPage />
      default:
        return <Dashboard setActiveModule={setActiveModule} />
    }
  }

  return (
    <SidebarProvider>
      <AppSidebar activeModule={activeModule} setActiveModule={setActiveModule} />
      <SidebarInset>
        <header className="flex h-16 shrink-0 items-center gap-2 border-b px-4">
          <SidebarTrigger className="-ml-1" /> {/* Moved SidebarTrigger here */}
          <Separator orientation="vertical" className="mr-2 h-4" /> {/* Added Separator */}
          <div className="flex items-center gap-2">
            <h1 className="text-lg font-semibold text-slate-500">FibreFlow</h1>
          </div>
        </header>
        <main className="flex-1 overflow-auto p-4">{renderModule()}</main>
      </SidebarInset>
    </SidebarProvider>
  )
}
